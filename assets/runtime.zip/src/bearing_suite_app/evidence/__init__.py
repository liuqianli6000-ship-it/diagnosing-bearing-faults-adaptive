﻿"""Evidence gate and provenance."""
